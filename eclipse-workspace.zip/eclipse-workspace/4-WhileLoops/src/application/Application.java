package application;

public class Application {

	public static void main(String[] args) {
		int value = 0;

		while (value < 10) {
			System.out.println("Hello " + value);

			value = value + 1;
		}

	}

}

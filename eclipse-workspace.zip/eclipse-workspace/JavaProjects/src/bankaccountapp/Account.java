package bankaccountapp;

public abstract class Account implements IRate {
	// List common properties for savings and checking accounts
	String name;
	String sSN;
	double balance;
	
	String acountNumber;
	double rate;
	// Constructor to set base properties and initialize the account

	public Account(String name, String sSN, double initDeposit) {
		
	}
	
	// List common methods
}

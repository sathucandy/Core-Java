package bankaccountapp;

public class Checking extends Account {

	// List properties specific to checking account
	int debitCardNumber;
	int debitCardPin;

	// Constructor to initialize checking account properties

	public Checking(String name, String sSN, double initDeposit) {
		super(name, sSN, initDeposit);
		System.out.println("New checking account");
		System.out.println("Name is " + name);
	}

	// List any methods specific to checking account
}

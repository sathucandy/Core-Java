package bankaccountapp;

public class BankAccountApp {

	public static void main(String[] args) {

		Checking chkacc1 = new Checking("Tom Wilson", "123456789", 1500);

		Savings savacc1 = new Savings("Rich Love", "987654321", 2500);

		// Read a CSV file then create new accounts based on that data

	}

}

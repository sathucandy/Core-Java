package bankaccountapp;

public interface IRate {
	
	// Methods to implement common base rates

}

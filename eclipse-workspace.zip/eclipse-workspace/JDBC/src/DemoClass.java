import java.sql.*;
/*
 *  
 * 1. import ----> java.sql
 * 2. load and register the driver ---> com.mysql.jdbc.Driver
 * 3. Create Connection -----> Connection
 * 4. create a statement -----> Statement
 * 5. execute the query ----->
 * 6. process the results ----->
 * 7. close
 * 
 */

public class DemoClass {

	public static void main(String[] args) throws Exception {

		String url = "";
		String uname = "root";
		String pass = "";
		int userid = 5;
		String username = "Ali";
		String query = "insert into student values (?,?)";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uname, pass);
		// Statement st = con.createStatement();
		PreparedStatement st = con.prepareStatement(query); // PreparedStatement
		st.setInt(1, userid); // THE IS IS THE NUMBER OF QUESTION MARK
		st.setString(2, username);
		/*
		 * // FOR GETTING THE DATA ResultSet rs = st.executeQuery(query); // DDL, DML,
		 * DQL String userdata = "";
		 * 
		 * while (rs.next()) { userdata = rs.getInt(1) + ":" + rs.getString("2");
		 * System.out.println(userdata); }
		 */

		int count = st.executeUpdate(); // FOR INSERTING THE DATA
		System.out.println(count + "row(s) affected");
		st.close();
		con.close();
	}

}

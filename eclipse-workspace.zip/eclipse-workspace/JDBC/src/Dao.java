import java.sql.*;

public class Dao {

	public static void main(String[] args) {
		StudentDAO dao = new StudentDAO();
		// Student s1 = dao.getStudent(12);
		Student s2 = new Student();
		s2.rollno = 15;
		s2.sname = "Archana";
		dao.connect();
		dao.addStudent(s2);
		// System.out.println(s1.sname);
	}
}

class StudentDAO {
	Connection con = null;

	public void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("", "root", "0");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Student getStudent(int rollno) {
		try {
			Student s = new Student();
			s.rollno = rollno;

			String query = "select sname from student where rollno=" + rollno;

			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			rs.next();
			String name = rs.getString(1);
			s.sname = name;
			return s;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public void addStudent(Student s) {
		String query = "insert into Student values(?,?)";
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(query);
			pst.setInt(1, s.rollno);
			pst.setString(2, s.sname);
			pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

class Student {
	int rollno;
	String sname;
}

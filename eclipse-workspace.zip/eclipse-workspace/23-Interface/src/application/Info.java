package application;

public interface Info {
	public void showInfo();
}
